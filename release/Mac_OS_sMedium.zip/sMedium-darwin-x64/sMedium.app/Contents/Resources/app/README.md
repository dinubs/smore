# sMedium

### Development

1. `npm install`
2. Talk to Gavin about Medium api keys.
3. Make file in `/app` called `settings.json` add in `{"user": {}}`
4. `npm run dev`
5. You should see screen saying you need to sign in.