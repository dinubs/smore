import React from 'react';
import styles from './styles.css';

const P = (props) => <p className={styles.P} {...props}></p>

module.exports = P;